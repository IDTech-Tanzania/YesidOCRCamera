//
//  YesidOCRCamera.h
//  YesidOCRCamera
//
//  Created by Emmanuel Mtera on 4/18/23.
//

#import <Foundation/Foundation.h>

//! Project version number for YesidOCRCamera.
FOUNDATION_EXPORT double YesidOCRCameraVersionNumber;

//! Project version string for YesidOCRCamera.
FOUNDATION_EXPORT const unsigned char YesidOCRCameraVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YesidOCRCamera/PublicHeader.h>


